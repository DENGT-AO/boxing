/*
 * $Id: $ --
 *
 *  Ngrok Packet C File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 27/03/2017
 * Author: Henri HAN
 *
 */
 
#include <syslog.h>
#include <jansson.h>
#include  <errno.h>
#include <string.h>
#include <event2/dns.h>
#include <event2/bufferevent_ssl.h>
#include <event2/util.h>
#include "ngrok_def.h"
#include "ngrok.h"
#include "bytetools.h"

NG_LINK proxy_tunnel[MAX_LINK];

static int ngrok_auth_req_handle(void *context, void *data, void *args);
static int ngrok_auth_resp_handle(void *context, void *data, void *args);
static int ngrok_req_tunnel_handle(void *context, void *data, void *args);
static int ngrok_new_tunnel_handle(void *context, void *data, void *args);
static int ngrok_req_proxy_handle(void *context, void *data, void *args);
static int ngrok_reg_proxy_handle(void *context, void *data, void *args);
static int ngrok_start_proxy_handle(void *context, void *data, void *args);
static int ngrok_ping_handle(void *context, void *data, void *args);
static int ngrok_pong_handle(void *context, void *data, void *args);
static int ngrok_close_handle(void *context, void *data, void *args);

static NGROK_EVENT_HANDLE ngrok_event_handle[] = {
	{.type = "Auth",     	.handle = &ngrok_auth_req_handle, 	.args = &gl_ng_conf},
	{.type = "AuthResp", 	.handle = &ngrok_auth_resp_handle, 	.args = NULL},
	{.type = "ReqTunnel", 	.handle = &ngrok_req_tunnel_handle, .args = &gl_ng_conf},
	{.type = "NewTunnel",  	.handle = &ngrok_new_tunnel_handle, .args = &gl_ng_conf},
	{.type = "ReqProxy",   	.handle = &ngrok_req_proxy_handle, 	.args = NULL},
	{.type = "RegProxy",   	.handle = &ngrok_reg_proxy_handle, 	.args = &gl_ng_client},
	{.type = "StartProxy", 	.handle = &ngrok_start_proxy_handle,.args = NULL},
	{.type = "Ping", 		.handle = &ngrok_ping_handle, 		.args = NULL},
	{.type = "Pong", 		.handle = &ngrok_pong_handle, 		.args = NULL},
	{.type = "Close", 		.handle = &ngrok_close_handle, 		.args = NULL}
};

static int get_empty_tunnel_idx()
{	
	int index = 0;

	for(index = 0; index < MAX_LINK; index++){
		if(proxy_tunnel[index].id == -1){
			return index;
		}
	}
	return -1;
}

static int tunnel_is_full()
{	
	int index = 0;

	for(index = 0; index < MAX_LINK; index++){
		if(proxy_tunnel[index].id == -1){
			return 0;
		}
	}
	return 1;
}

static int send_pack(struct bufferevent *bev, char *buf, unsigned int len)
{
	unsigned char *buffer = NULL;
	unsigned long long packlen = (unsigned long long)len;
	int ret = -1;

	syslog(LOG_DEBUG,"send buf %s len %d", buf, len);
	if(len > 0){
		buffer = calloc(len+9, sizeof(unsigned char));
		packlen=LittleEndian_64(packlen);
		memcpy(buffer,&packlen, NGROK_PACK_HDR_SIZE); // 8 bytes package header
		memcpy(buffer+NGROK_PACK_HDR_SIZE, buf, len);
		ret = bufferevent_write(bev, buffer, len+NGROK_PACK_HDR_SIZE);
		if(ret == -1){
			syslog(LOG_ERR,"send packet err");
		}

		free(buffer);
	}

	return ret;
}

static int parse_auth_resp(NGROK_CLIENT *client, json_t *auth)
{
	json_t *version_obj, *mmver_obj, *clientid_obj, *error_obj;
	NGROK_PRIO *prio = &client->prio;

	error_obj = json_object_get(auth, "Error");
	if(!json_is_string(error_obj)){
        syslog(LOG_ERR, "ngctrl error: error is not a string\n");
        return NG_ERR;
	}

	if(json_string_length(error_obj)){
		syslog(LOG_ERR, "ngctrl error: %s\n", json_string_value(error_obj));
		return NG_ERR;
	}
	
	version_obj = json_object_get(auth, "Version");
	if(!json_is_string(version_obj)){
		syslog(LOG_ERR, "ngctrl error: version is not a string\n");
		return NG_ERR;
	}

	if(strcmp(prio->version, json_string_value(version_obj))){
		syslog(LOG_ERR, "ngctrl error: config version %s is not conrespondent\n",prio->version);
		return NG_ERR;
	}
	
	mmver_obj = json_object_get(auth, "MmVersion");
	if(!json_is_string(mmver_obj)){
		syslog(LOG_ERR, "ngctrl error: mmver is not a string\n");
        return NG_ERR;
	}

	if(strcmp(prio->mm_ver, json_string_value(mmver_obj))){
		syslog(LOG_ERR, "ngctrl error: config s_mmver %s is not conrespondent\n",  prio->mm_ver);
		return NG_ERR;
	}

	clientid_obj = json_object_get(auth, "ClientId");
	if(!json_is_string(clientid_obj)){
        syslog(LOG_ERR, "ngctrl error: clientid is not a string\n");
        return NG_ERR;
	}

	snprintf(prio->clientid, sizeof(prio->clientid), "%s", json_string_value(clientid_obj));
	syslog(LOG_DEBUG, "ngctrl get clientid %s\n", prio->clientid);

	return NG_OK;
}

static int parse_new_tunnel(NGROK_CLIENT *client, json_t *tunnel, NGROK_CONF *conf)
{
	json_t *reqid_obj, *url_obj, *proto_obj, *error_obj;
	NGROK_PRIO *prio = &client->prio;
	char cmd[1024] = {0};

	if(!client || !tunnel || !conf){
		return NG_PARAM_NULL;
	}

	error_obj = json_object_get(tunnel, "Error");
	if(!json_is_string(error_obj)){
		syslog(LOG_ERR, "ngctrl error: error is not a string\n");
		return NG_ERR;
	}
	
	if(json_string_length(error_obj)){
		syslog(LOG_ERR, "ngctrl error: %s\n", json_string_value(error_obj));
		return NG_ERR;
	}

	reqid_obj = json_object_get(tunnel, "ReqId");
	if(!json_is_string(reqid_obj)){
		syslog(LOG_ERR, "ngctrl error: ReqID is not a string\n");
		return NG_ERR;
	}

	if(strcmp(conf->tunnelId, json_string_value(reqid_obj))){
		syslog(LOG_ERR, "ngctrl error:config reqid %s is not conrespondent\n", conf->tunnelId);
		return NG_ERR;
	}

	proto_obj = json_object_get(tunnel, "Protocol");
	if(!json_is_string(proto_obj)){
		syslog(LOG_ERR, "ngctrl error: protocol is not a string\n");
		return NG_ERR;
	}

	if(strcmp(conf->proto, json_string_value(proto_obj))){
		syslog(LOG_ERR, "ngctrl error:config proto %s is not conrespondent\n", conf->proto);
		return NG_ERR;
	}

	url_obj = json_object_get(tunnel, "Url");
	if(!json_is_string(url_obj)){
		syslog(LOG_ERR, "ngctrl error: url is not a string\n");
		return NG_ERR;
	}


	snprintf(prio->url, sizeof(prio->url), "%s", json_string_value(url_obj));
	syslog(LOG_DEBUG, "ngctrl url %s\n", prio->url);
	snprintf(cmd, sizeof(cmd), "echo -e \"%s\n%s\" > %s/ngroklink%d", prio->url, json_string_value(json_object_get(tunnel, "Token")), NGROK_LINK_DIR, pid);
	system(cmd);

	return NG_OK;	
}

int send_ng_msg(const char *type, void *context)
{
	NGROK_EVENT_HANDLE *ngrok = NULL;

	if(!type || !context){
		return NG_PARAM_NULL;
	}

	ngrok = NGROK_EVENT_HANDLE_CALLBACK(type);
	if(!ngrok){
		syslog(LOG_ERR, "%s handle callback not found!", type);
		return NG_ERR;
	}

	return ngrok->handle(context, NULL, ngrok->args);
}

int send_ng_ping(NGROK_CLIENT *client)
{
	NGROK_EVENT_HANDLE *ngrok = NULL;

	ngrok = NGROK_EVENT_HANDLE_CALLBACK("Ping");
	if(!ngrok){
		syslog(LOG_ERR, "Ping handle callback not found!");
		return NG_ERR;
	}

	return ngrok->handle(client, NULL, ngrok->args);
}

static int ngrok_auth_req_handle(void *context, void *data, void *args)
{	
	char buf[256];
	unsigned int buflen;
	NGROK_CLIENT *client = NULL;
	NGROK_PRIO *prio = NULL;
	NGROK_CONF *ngrok_conf = NULL;

	if(!context || !args){
		return NG_PARAM_NULL;
	}

	client = (NGROK_CLIENT *)context;
	prio = &client->prio;

	ngrok_conf = (NGROK_CONF *)args;

	buflen = snprintf(buf, sizeof(buf), "{\"Type\":\"Auth\",\"Payload\":{\"OS\":\"%s\",\"ClientId\":\"\",\"MmVersion\":\"%s\",\"Version\":\"%s\",\"User\": \"%s\",\"Password\":\"%s\",\"Arch\":\"%s\"}}", prio->os, prio->mm_ver, prio->version, ngrok_conf->username, ngrok_conf->password, prio->arch);

	return send_pack(client->bev, buf, buflen);
}

static int ngrok_auth_resp_handle(void *context, void *data, void *args)
{
	json_t *payload_obj = NULL;
	NGROK_CLIENT *client = NULL;

	if(!context || !data){
		return NG_PARAM_NULL;
	}

	client = (NGROK_CLIENT *)context;

	payload_obj = json_object_get((json_t *)data, "Payload");
	if(!json_is_object(payload_obj)){
		syslog(LOG_ERR, "ngctrl error payload auth rep is not an object\n");
		goto PARSE_FAIL;
	}else{
		if(parse_auth_resp(client, payload_obj) != NG_OK){
			syslog(LOG_ERR,"parse auth rep error");
			goto PARSE_FAIL;
		}

		if(send_ng_msg("Ping", client) < 0){
			syslog(LOG_ERR,"send ping err");
			goto PARSE_FAIL;
		}

		if(send_ng_msg("ReqTunnel", client) != NG_OK){
			syslog(LOG_ERR,"send reg tunnel err");
			goto PARSE_FAIL;
		}
	}

	return NG_OK;

PARSE_FAIL:
	return NG_ERR;
}

static int ngrok_req_tunnel_handle(void *context, void *data, void *args)
{
	char buf[256];
	unsigned int buflen;
	NGROK_CLIENT *client = NULL;
	NGROK_CONF *ngrok_conf = NULL;
	char sub[16]="hihihi";

	if(!context || !args){
		return NG_PARAM_NULL;
	}

	client = (NGROK_CLIENT *)context;
	ngrok_conf = (NGROK_CONF *)args;

	buflen = snprintf(buf, sizeof(buf), "{\"Type\":\"ReqTunnel\",\"Payload\":{\"HttpAuth\":\"%s\",\"Protocol\":\"%s\",\"Hostname\":\"\",\"ReqId\": \"%s\",\"Subdomain\":\"%s\"}}", 
																																	ngrok_conf->httpAuth, ngrok_conf->proto, ngrok_conf->tunnelId, sub);

	return send_pack(client->bev, buf, buflen);
}

static int ngrok_new_tunnel_handle(void *context, void *data, void *args)
{
	json_t *payload_obj = NULL;
	NGROK_CLIENT *client = NULL;
	NGROK_CONF *ngrok_conf = NULL;

	if(!context || !data){
		return NG_PARAM_NULL;
	}

	client = (NGROK_CLIENT *)context;
	ngrok_conf = (NGROK_CONF *)args;

	payload_obj = json_object_get((json_t *)data, "Payload");
	if(!json_is_object(payload_obj)){
		syslog(LOG_ERR, "ngctrl error payload new tunnel is not an object\n");
		goto PARSE_FAIL;
	}

	if(parse_new_tunnel(client, payload_obj, ngrok_conf) != NG_OK){
		syslog(LOG_ERR,"parse new tunnel error");
		goto PARSE_FAIL;
	}

	client->stat = NG_SM_CONNECTED;
	syslog(LOG_INFO,"state:Connecting-->Connected");

	return NG_OK;
PARSE_FAIL:
	return NG_ERR;
}

static int ngrok_req_proxy_handle(void *context, void *data, void *args)
{
	NGROK_CLIENT *client = NULL;
	int tunnel_idx = 0;
	NG_LINK *proxy = NULL;

	if(!context){
		return NG_PARAM_NULL;
	}

	client = (NGROK_CLIENT *)context;

	tunnel_idx = get_empty_tunnel_idx();
	if(tunnel_idx < 0){
		syslog(LOG_WARNING, "tunnel proxy pool is full");
		return NG_ERR;
	}

	proxy = &proxy_tunnel[tunnel_idx];
	proxy->id = tunnel_idx;

	ngrok_client_restart_timer(client->hbtmr, client->keepalive);
	if(create_remote_link(client, proxy) != NG_OK){
		syslog(LOG_ERR, "creat remote proxy tunnel link fail");
		return NG_ERR;
	}

	return NG_OK;
}

static int ngrok_reg_proxy_handle(void *context, void *data, void *args)
{
	char buf[128];
	unsigned int buflen;
	NG_LINK *link = NULL;
	NGROK_PRIO *prio = NULL;


	if(!context || !args){
		return NG_PARAM_NULL;
	}

	link = (NG_LINK *)context;
	prio = &((NGROK_CLIENT *)args)->prio;

	buflen = snprintf(buf, sizeof(buf), "{\"Type\":\"RegProxy\",\"Payload\":{\"ClientId\":\"%s\"}}", prio->clientid);

	return send_pack(link->remote_bev, buf, buflen);
}

static int ngrok_start_proxy_handle(void *context, void *data, void *args)
{
	int ret = NG_UNKNOWN_ERR;
	NG_LINK *link = NULL;
	json_t *payload_obj = NULL;
	json_t *url_obj = NULL;
	json_t *clientaddr_obj = NULL;
	const char *url = NULL;
	const char *clientaddr = NULL;

	if(!context || !data){
		return NG_PARAM_NULL;
	}

	link = (NG_LINK *)context;

	payload_obj = json_object_get((json_t *)data, "Payload");
	if(!json_is_object(payload_obj)){
		syslog(LOG_ERR, "ngproxy error payload is not an object\n");
		ret = NG_PARAM_INVALID;
		goto PARSE_FAIL;
	}
	
	url_obj = json_object_get(payload_obj, "Url");
	if(!json_is_string(url_obj)){
		syslog(LOG_ERR, "ngproxy error: url is not a string\n");
		ret = NG_PARAM_INVALID;
		goto PARSE_FAIL;
	}

	url = json_string_value(url_obj);
	if(!url){
		syslog(LOG_ERR, "ngproxy error: extract url failed\n");
		ret = NG_ERR;
		goto PARSE_FAIL;
	}
					
	snprintf(link->url, sizeof(link->url), "%s", url);
	syslog(LOG_DEBUG, "ngproxy get url %s\n", link->url);
				
	clientaddr_obj = json_object_get(payload_obj, "ClientAddr");
	if(!json_is_string(clientaddr_obj)){
		syslog(LOG_ERR, "ngproxy error: client addr is not a string\n");
		ret = NG_PARAM_INVALID;
		goto PARSE_FAIL;
	}
	
	clientaddr = json_string_value(clientaddr_obj);
	if(!clientaddr){
		syslog(LOG_ERR, "ngproxy error: extract clientaddr failed\n");
		ret = NG_ERR;
		goto PARSE_FAIL;
	}

	snprintf(link->clientaddr, sizeof(link->clientaddr), "%s", clientaddr);
	syslog(LOG_DEBUG, "ngproxy get client addr %s\n", link->clientaddr);

	link->stat = NGLINK_CONNECTED;
	ret = NG_OK;

PARSE_FAIL:
	return ret;
}

static int ngrok_ping_handle(void *context, void *data, void *args)
{
	char buf[32];
	unsigned int buflen;
	NGROK_CLIENT *client = NULL;

	if(!context){
		return NG_PARAM_NULL;
	}

	client = (NGROK_CLIENT *)context;
	
	buflen = snprintf(buf, sizeof(buf), "{\"Type\":\"Ping\",\"Payload\": \{}}");
	
	return send_pack(client->bev, buf, buflen);
}

static int ngrok_pong_handle(void *context, void *data, void *args)
{
	return NG_OK;
}

static int ngrok_close_handle(void *context, void *data, void *args)
{
	NGROK_CLIENT *client = NULL;

	if(!context){
		exit(0);
	}

	client = (NGROK_CLIENT *)context;

	syslog(LOG_INFO, "ngrok exit ...");
	event_base_loopbreak(client->base);

	return NG_OK;
}

int ngproxy_packet_parse(NG_LINK *link, struct evbuffer *input, int len)
{
	json_t *root_obj = NULL;
    json_error_t error;
	json_t *type_obj = NULL;
	int ret = NG_UNKNOWN_ERR;
	char recvbuf[256];
	char type[32] = {0};
	NGROK_EVENT_HANDLE *ngrok = NULL;


	evbuffer_remove(input, recvbuf, len);
	recvbuf[len] = '\0';
	syslog(LOG_DEBUG, "ngproxy recv buf %s\n", recvbuf);

	root_obj = json_loads(recvbuf, 0, &error);
	if(!root_obj){
		syslog(LOG_ERR, "ngproxy error: on line %d: %s\n", error.line, error.text);
		return NG_ERR;
	}		

	type_obj = json_object_get(root_obj, "Type");
	if(!json_is_string(type_obj)){
        syslog(LOG_ERR, "ngproxy error: type is not a string\n");
		goto PARSE_FAIL;
	}
	
	snprintf(type, sizeof(type), "%s", json_string_value(type_obj));

	ngrok = NGROK_EVENT_HANDLE_CALLBACK(type);
	if(!ngrok){
		goto PARSE_FAIL;
	}

	ret = ngrok->handle(link, root_obj, ngrok->args);

PARSE_FAIL:
	json_decref(root_obj);
	return ret;
}

int ngctrl_packet_parse(NGROK_CLIENT *client, struct evbuffer *input, int len)
{
	json_t *root_obj = NULL;
    json_error_t error;
	json_t *type_obj = NULL;
	const char *type_val = NULL;
	char recvbuf[512] = {0};
	int ret = NG_ERR;
	NGROK_EVENT_HANDLE *ngrok = NULL;

	if(tunnel_is_full()){
		syslog(LOG_WARNING, "tunnel proxy pool is full");
		return NG_ERR;
	}
	
	evbuffer_remove(input, recvbuf, len);
	recvbuf[len]='\0';
	syslog(LOG_DEBUG, "ngctrl recv buf %s\n", recvbuf);


	root_obj = json_loads(recvbuf, 0, &error);
	if(!root_obj){
		syslog(LOG_ERR, "ngctrl error: on line %d: %s\n", error.line, error.text);
		return NG_ERR;
	}


	type_obj = json_object_get(root_obj, "Type");
	if(!json_is_string(type_obj)){
		syslog(LOG_ERR, "ngctrl error: type is not a string\n");
		goto PARSE_FAIL;
    }


	type_val = json_string_value(type_obj);
	if(NULL == type_val) {
		syslog(LOG_ERR, "get json type field failed");
		goto PARSE_FAIL;
	}


	syslog(LOG_DEBUG, "ngctrl recvmsg get type  %s\n", type_val);
	ngrok = NGROK_EVENT_HANDLE_CALLBACK(type_val);
	if(!ngrok){
		goto PARSE_FAIL;
	}

	ret = ngrok->handle(client, (void *)root_obj, ngrok->args);

PARSE_FAIL:
	json_decref(root_obj);

	return ret;
}
