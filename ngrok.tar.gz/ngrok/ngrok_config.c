/*
 * $Id: $ --
 *
 *  Ngrok conf C File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 29/03/2017
 * Author: Henri HAN
 *
 */
//#include <netdb.h>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <arpa/inet.h>
#include <syslog.h>

#include "ngrok_def.h"
extern NG_LINK proxy_tunnel[MAX_LINK];

//char remotehost[] = "tunnel.qydev.com";
//char remotehost[] = "123.57.165.240";
//char remotehost[] = "192.168.31.218";
//char remotehost[] = "office.j3r0lin.com";
//int remoteport = 4443;
//int remoteport = 9999;
//char localhost[] = "127.0.0.1";
//int localport = 80;
/*
int ngconf_get_sa(TYPE_SA type, struct sockaddr_in *sa)
{
	struct hostent *host = NULL;
	
	memset(sa, 0, sizeof(struct sockaddr_in));
    	sa->sin_family = AF_INET;
	if(type == REMOTE_SA){
		sa->sin_port = htons(remoteport);
		host = gethostbyname(remotehost);
	}else if(type == LOCAL_SA){
		sa->sin_port = htons(localport);
		host = gethostbyname(localhost);
	}
	if(host == NULL){
		syslog(LOG_INFO, "The domain name queries failed! error(%d):%s", h_errno, hstrerror(h_errno));	
		return -1;
	}else{
		memcpy(&sa->sin_addr, host->h_addr_list[0], sizeof(sa->sin_addr));
	}			
	return 0;
}

int ngconf_get_sa(TYPE_SA type, struct sockaddr_in *sa)
{
	memset(sa, 0, sizeof(struct sockaddr_in));
    	sa->sin_family = AF_INET;
	if(type == REMOTE_SA){
		sa->sin_port = htons(remoteport);
		sa->sin_addr.s_addr =  inet_addr(remotehost);
	}else if(type == LOCAL_SA){
		sa->sin_port = htons(localport);
		sa->sin_addr.s_addr =  inet_addr(localhost);
	}
	syslog(LOG_INFO, "get sa ok");			
	return 0;
}
*/



