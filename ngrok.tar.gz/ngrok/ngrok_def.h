/*
 * $Id: $ --
 *
 *  Ngrok Client def Head File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 27/03/2017
 * Author: Henri HAN
 *
 */
 
 
#ifndef _NGROK_DEF_H_
#define _NGROK_DEF_H_

#include <openssl/ssl.h>
#include <event.h>
#include "mosq_def.h"
#define NGROK_PACK_HDR_SIZE	8

#define MAX_LINK	100
#define MAX_HOSTNAME_LEN	512

#define NGROK_LINK_DIR			"/tmp/ngrok"
#define NGROK_PROXY_CONF_FILE 	NGROK_LINK_DIR"/ngrokproxy.conf"

typedef enum{
	NG_OK = 0,
	NG_ERR = -1,
	NG_PARAM_INVALID = -2,
	NG_PARAM_NULL = -3,
	NG_UNKNOWN_ERR = -4,
}NG_ERR_CODE;

typedef enum ng_stat{
	NG_SM_INIT = 0,
	NG_SM_CONFIG,
	NG_SM_CONNECTING,
	NG_SM_CONNECTED
}NG_STAT;

typedef enum nglink_stat{
	NGLINK_INIT = 0,
	NGLINK_REMOTED,
	NGLINK_CONNECTED,
	NGLINK_FINISHED
}NGLINK_STAT;

typedef struct ng_link{
	int id;
	SSL *ssl;
	struct bufferevent *remote_bev;
	struct bufferevent *local_bev;
	char url[128];
	char clientaddr[32]; 
	NGLINK_STAT stat;
	struct event_base *base;
}NG_LINK;

typedef struct ngrok_prio{
	char version[8];
	char mm_ver[8];
	char arch[8];
	char os[16];
	char clientid[40];
	char url[128];
	char clientaddr[32];
}NGROK_PRIO;

typedef struct ngrok_client{
	NG_STAT stat;
	NGROK_PRIO prio;
	SSL_CTX  *ssl_ctx;
	SSL *ssl;
	struct sockaddr_in sa;	
	struct bufferevent *bev;
	struct event_base *base;
	//struct evdns_base *dns_base;
	struct event *evtmr;
	struct event *hbtmr;
	struct sockaddr_in sin;

	int keepalive;
}NGROK_CLIENT;

typedef int (*NGROK_HANDLE_CALLBACK)(void *context, void *data, void *args);
typedef struct ngrok_handle{
	char type[32];
	NGROK_HANDLE_CALLBACK handle;
	void *args;
}NGROK_EVENT_HANDLE;

#define NGROK_EVENT_HANDLE_CALLBACK(_type) ({ \
			int index = 0; \
			NGROK_EVENT_HANDLE *cb = NULL; \
			for(index = 0; index < sizeof(ngrok_event_handle) / sizeof(ngrok_event_handle[0]); index++){ \
				if(strcmp(_type, ngrok_event_handle[index].type) == 0){ \
					cb = &ngrok_event_handle[index]; \
					break; \
				}\
			} \
			cb; \
		})

typedef void (*NGROK_PROXY_RDWR_CALLBACK)(struct bufferevent *bev, void *arg);
typedef void (*NGROK_PROXY_EVENT_CALLBACK)(struct bufferevent *bev, short events, void *ptr);
typedef int (*NGROK_PROXY_HANDLE)(void *context, void *data, void *args);

typedef struct ngrok_local_proxy{
	char proto[32];

	NGROK_PROXY_RDWR_CALLBACK read_cb;
	NGROK_PROXY_RDWR_CALLBACK write_cb;
	NGROK_PROXY_EVENT_CALLBACK event_cb;

	NGROK_PROXY_HANDLE handle;
}NGROK_PROXY_CONTEXT;

#define NGROK_PROXY_HANDLE_CALLBACK(_proto) ({ \
			int index = 0; \
			NGROK_PROXY_CONTEXT *cb = NULL; \
			for(index = 0; index < sizeof(ngrok_proxy_handle) / sizeof(ngrok_proxy_handle[0]); index++){ \
				if(strcmp(_proto, ngrok_proxy_handle[index].proto) == 0){ \
					cb = &ngrok_proxy_handle[index]; \
					break; \
				}\
			} \
			cb; \
		})


#define DEFAULT_NGPROK_KEEPALIVE	300 

typedef struct ngrok_conf{
	char server_host[128];
	int server_port;

	char username[128];
	char password[128];

	char host[128];
	int port;
	char proto[32];
	char httpAuth[128];
	char tunnelId[128];

	int keepalive;
}NGROK_CONF;

typedef enum connect_type{
	CON_TYPE_SHORT = 0,
	CON_TYPE_LONG
}CON_TYPE;

typedef void (*NGROK_TUNNEL_RDWR_CALLBACK)(struct bufferevent *bev, void *arg);
typedef void (*NGROK_TUNNEL_EVENT_CALLBACK)(struct bufferevent *bev, short events, void *ptr);
typedef enum{
	NGROK_CTRL_TUNNEL = 0,
	NGROK_PROXY_TUNNEL
}NGROK_TUNNEL_TYPE;
	
#endif
