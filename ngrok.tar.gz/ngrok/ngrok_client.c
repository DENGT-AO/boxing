/*
 * $Id: $ --
 *
 *  Ngrok link C File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 28/03/2017
 * Author: Henri HAN
 *
 */
#include <unistd.h>
#include <stddef.h>
#include <sys/un.h>
#include <arpa/inet.h> 
#include <syslog.h>
#include <errno.h>
#include <event2/dns.h>
#include <event2/bufferevent_ssl.h>
#include <event2/util.h>
#include "ngrok_def.h"
#include "ngrok.h"

extern NG_LINK proxy_tunnel[MAX_LINK];

static int get_tunnel_link_num()
{	
	int i;
	int cnt = 0;

	for(i = 0; i<MAX_LINK; i++){
		if(proxy_tunnel[i].stat == NGLINK_CONNECTED){
			cnt++;
		}
	}
	return cnt;
}

static void ngclient_read_cb(struct bufferevent *bev, void *arg)
{
	NGROK_CLIENT *client = (NGROK_CLIENT *)arg;
	struct evbuffer *input = bufferevent_get_input(bev);
	size_t len = evbuffer_get_length(input);
	unsigned long long packlen = 0;

	syslog(LOG_DEBUG, "ngclient recv len %d", len);
	evbuffer_copyout(input, (void *)&packlen, NGROK_PACK_HDR_SIZE);

	syslog(LOG_DEBUG, "ngclient get package len %lld", packlen);
	if(len >= packlen + NGROK_PACK_HDR_SIZE){
		evbuffer_drain(input, NGROK_PACK_HDR_SIZE);
		ngctrl_packet_parse(client, input, (int)packlen);
	}
}

static void ngclient_event_cb(struct bufferevent *bev, short events, void *arg)
{
	NGROK_CLIENT *client = (NGROK_CLIENT *)arg;

	if(events & BEV_EVENT_CONNECTED){
		syslog(LOG_DEBUG, "ngclient Connection created\n");
		send_ng_msg("Auth", client);
		client->stat = NG_SM_CONNECTING;
	}else if(events & (BEV_EVENT_EOF|BEV_EVENT_ERROR
						|BEV_EVENT_TIMEOUT|BEV_EVENT_READING|BEV_EVENT_WRITING)){
		if(!(events & BEV_EVENT_EOF)){
			syslog(LOG_ERR, "ngclient got an error on the connection: %s \n", evutil_socket_error_to_string(EVUTIL_SOCKET_ERROR()));
		}

		close_ctrl_tunnel(client);
		client->stat = NG_SM_CONFIG;
	}
}


static void ngrok_hb_timer_cb(int fd, short event, void *arg)
{
	NGROK_CLIENT *client = (NGROK_CLIENT *)arg;
	int link_num = get_tunnel_link_num();

	if(link_num > 3){
		syslog(LOG_NOTICE, "ngclient link size is %d, cannot disconnect", link_num);
		ngrok_client_restart_timer(client->hbtmr, client->keepalive);
	}else{
		syslog(LOG_NOTICE, "ngclient req timeout close client.");
		event_base_loopbreak(client->base);
	}
}

static void ngclient_sm_cb(int fd, short event, void *arg)
{
	NGROK_CLIENT *client = (NGROK_CLIENT *)arg;
	int timer = 20;

	switch(client->stat){
		case NG_SM_INIT:
			syslog(LOG_INFO, "state: Init-->Config");
			client->stat = NG_SM_CONFIG;
			timer = 1;
			break;
		case NG_SM_CONFIG:
			syslog(LOG_INFO, "state: Config-->Connecting");
			create_ctrl_tunnel(client);
			break;
		case NG_SM_CONNECTING:
			break;
		case NG_SM_CONNECTED:
			send_ng_msg("Ping", client);
			break;
		default:
			break;
	}

	ngrok_client_restart_timer(client->evtmr, timer);
}

int create_ctrl_tunnel(NGROK_CLIENT *client)
{	
	return create_ngrok_tunnel(NGROK_CTRL_TUNNEL, client, NULL, ngclient_read_cb, NULL, ngclient_event_cb, client);
}

int close_ctrl_tunnel(NGROK_CLIENT *client)
{
	syslog(LOG_INFO, "ngclient close tunnel\n");
	ng_free_ctx(&client->bev);

	return 0;
}

void ngrok_client_start(NGROK_CLIENT *client, int interval)
{
	struct timeval tv;
	evutil_timerclear(&tv);
	tv.tv_sec = interval;
	evtimer_add(client->evtmr, &tv);
	event_base_loop(client->base, 0);
}

int ngrok_client_init(NGROK_CLIENT *client)
{
	NGROK_PRIO *prio = &client->prio;

	memset(prio, 0, sizeof(NGROK_PRIO));
	memcpy(prio->version, "2.1", strlen("2.1")); 
	memcpy(prio->mm_ver, "1.8", strlen("1.8"));
	memcpy(prio->os, "linux", strlen("linux"));
	memcpy(prio->arch, "armv7", strlen("armv7"));

	memset(&client->sin, 0, sizeof(struct sockaddr_in));
	client->sin.sin_family = AF_INET;
	client->sin.sin_addr.s_addr = inet_addr(gl_ng_conf.server_host);
	client->sin.sin_port = htons(gl_ng_conf.server_port);

	client->ssl_ctx = NULL;
	client->ssl = NULL;

	client->keepalive = gl_ng_conf.keepalive;

	client->stat = NG_SM_INIT;
	client->base = event_base_new();
	if(NULL == client->base){
		syslog(LOG_ERR, "create event base error.");
		return NG_ERR;
	}

	client->evtmr = evtimer_new(client->base, ngclient_sm_cb, (void *)client);
	client->hbtmr = evtimer_new(client->base, ngrok_hb_timer_cb, (void *)client);

	return NG_OK;
}

void ngrok_client_restart_timer(struct event *evtmr, int interval)
{
	struct timeval tv;
	evutil_timerclear(&tv);
	tv.tv_sec = interval;
	event_del(evtmr);
	evtimer_add(evtmr, &tv);
	syslog(LOG_DEBUG, "restart ngrok client timer %d", interval);
}
