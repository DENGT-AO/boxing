
#include <openssl/rand.h>
#include <openssl/err.h> 
#include "ngrok.h" 

SSL_CTX * evssl_init(void)
{
    SSL_METHOD *meth = NULL;

    /* 
     * no need to do those again, because we use the same CTX
     * over and over again.
     */
    if(!gl_ng_client.ssl_ctx) {
        /* Initialize the OpenSSL library */
        SSL_library_init();
        SSL_load_error_strings();
        OpenSSL_add_all_algorithms();

        /* We MUST have entropy, or else there's no point to crypto. */
        if (!RAND_poll()){
            return NULL;
		}

        meth = (SSL_METHOD *)SSLv23_client_method();

        gl_ng_client.ssl_ctx = SSL_CTX_new(meth);
    }

	return gl_ng_client.ssl_ctx;
}
