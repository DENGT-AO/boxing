/*
 * $Id: $ --
 *
 *  Ngrok Packet C File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 30/03/2017
 * Author: Henri HAN
 *
 */
#include <string.h>
#include <syslog.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>
#include "ngrok_def.h"
#include "ngrok.h"

#define IDENT "ngrok"

NGROK_CLIENT gl_ng_client;
NGROK_CONF gl_ng_conf;
pid_t pid;
CON_TYPE connect_type = CON_TYPE_LONG;

static int write_pidtofile(const char *pidfile, pid_t pid)
{
	FILE *fp;
	char buf[16];

	sprintf(buf, "%u\n", pid);

	if ((fp = fopen(pidfile, "w")) != NULL) {
		fputs(buf, fp);
		fclose(fp);
		return 0;
  	}

	return errno;
}

static void signal_end( int nosig )
{
	syslog(LOG_WARNING, "ngclient recv singal terminate");
	exit(-1);
}

static void signal_user_open_debug( int nosig )
{
	syslog(LOG_NOTICE, "ngclient recv singal user1, open log debug");
	setlogmask(LOG_UPTO(LOG_DEBUG)); 
}

static void signal_user_close_debug( int nosig )
{
	syslog(LOG_NOTICE, "ngclient recv singal user2, close log debug");
	setlogmask(LOG_UPTO(LOG_INFO)); 
}

void usage(void)
{
	printf("=====================================================================\n");
    printf("Usage: ngrokc\n");
    printf("    -s    ngrok server address.\n");
    printf("    -p    ngrok server port.\n");
    printf("    -i    ngrok proxy host.\n");
    printf("    -l    ngrok proxy port.\n");
    printf("    -t    ngrok proxy protocol.\n");
    printf("    -a    ngrok http auth.\n");
    printf("    -u    ngrok auth username.\n");
    printf("    -d    ngrok auth password.\n");
    printf("    -r    ngrok tunnel ID.\n");
    printf("    -k    ngrok tunnel keep alive. Default 300s\n");
    printf("    -f    ngrok configure file.\n");
	printf("    -c    ngrok connect type.\n");
    printf("    -h    see help\n");
    printf("=====================================================================\n");
    exit(0);
}

static int ngrok_config_parse(const char *confile)
{
	FILE *fp = NULL;
    char buf[128] = {0};
    char *token = NULL;
    char *saveptr = NULL;
    char *p = NULL;
	NGROK_CONF *conf = &gl_ng_conf;

    if(!confile || access(confile, F_OK)){
        return NG_PARAM_NULL;
    }

    fp = fopen(confile, "r");
    if(NULL == fp){
        syslog(LOG_ERR, "load ngrok proxy config file error(%d:%s)", errno, strerror(errno));
        return NG_ERR;
    }

    while(fgets(buf, sizeof(buf), fp)){
        if(!buf[0] || buf[0] == '#' || buf[0] == '\n'){
            continue;
        }

		 p = strchr(buf, '\n');
        if(p){
            *p = '\0';
        }

        token = strtok_r(buf, "=", &saveptr);
        if(NULL == token){
            continue;
        }

		if(!strcmp(token, "server_host")){
			if(saveptr && strlen(saveptr) > 0){
                snprintf(conf->server_host, sizeof(conf->server_host), "%s", saveptr);
            }else{
                syslog(LOG_WARNING, "please specify server host");
                goto PARSE_CONF_FAIL;
            }
		}else if(!strcmp(token, "server_port")){
			if(saveptr && strlen(saveptr) > 0){
                conf->server_port = atoi(saveptr);
				if(conf->server_port < 1 || conf->server_port > 65535){
					syslog(LOG_WARNING, "service port is incorrect");
                	goto PARSE_CONF_FAIL;
				}
            }else{
                syslog(LOG_WARNING, "please specify server port");
                goto PARSE_CONF_FAIL;
            }
		}else if(!strcmp(token, "username")){
			if(saveptr && strlen(saveptr) > 0){
                snprintf(conf->username, sizeof(conf->username), "%s", saveptr);
            }else{
                syslog(LOG_WARNING, "please specify server auth username");
                goto PARSE_CONF_FAIL;
            }
		}else if(!strcmp(token, "password")){
			if(saveptr && strlen(saveptr) > 0){
                snprintf(conf->password, sizeof(conf->password), "%s", saveptr);
            }else{
                syslog(LOG_WARNING, "please specify server auth password");
                goto PARSE_CONF_FAIL;
            }
		}else if(!strcmp(token, "keepalive")){
			if(saveptr && strlen(saveptr) > 0){
				conf->keepalive = atoi(saveptr);
			}else{
				conf->keepalive = DEFAULT_NGPROK_KEEPALIVE;
			}
		}else if(!strcmp(token, "host")){
            if(saveptr && strlen(saveptr) > 0){
                snprintf(conf->host, sizeof(conf->host), "%s", saveptr);
            }else{
                syslog(LOG_WARNING, "please specify proxy host");
                goto PARSE_CONF_FAIL;
            }
        }else if(!strcmp(token, "port")){
			if(saveptr && strlen(saveptr) > 0){
                conf->port = atoi(saveptr);
				if(conf->port < 1 || conf->port > 65535){
					syslog(LOG_WARNING, "proxy port is incorrect");
					goto PARSE_CONF_FAIL;
				}
            }else{
                syslog(LOG_WARNING, "please specify proxy port");
                goto PARSE_CONF_FAIL;
            }
        }else if(!strcmp(token, "proto")){
            if(saveptr && strlen(saveptr) > 0){
                snprintf(conf->proto, sizeof(conf->proto), "%s", saveptr);
            }else{
                syslog(LOG_WARNING, "please specify proxy protocol");
                goto PARSE_CONF_FAIL;
            }
        }else if(!strcmp(token, "httpAuth")){
            snprintf(conf->httpAuth, sizeof(conf->httpAuth), "%s", saveptr);
        }else if(!strcmp(token, "tunnelId")){
            if(saveptr && strlen(saveptr) > 0){
                snprintf(conf->tunnelId, sizeof(conf->tunnelId), "%s", saveptr);
            }else{
                syslog(LOG_WARNING, "please specify proxy tunnel ID");
                goto PARSE_CONF_FAIL;
            }
        }

        memset(buf, 0, sizeof(memset));
	}
	fclose(fp);

	return NG_OK;

PARSE_CONF_FAIL:
	fclose(fp);

	return NG_ERR;
}

static int ngrok_scan_proxy_host(NGROK_CONF *conf)
{
	char cmd[128] = {0};
	int status = 0;

	if(!conf){
		return NG_PARAM_NULL;
	}

	// default tcp protocol
	snprintf(cmd, sizeof(cmd), "netcat -i 2 -z -w 10 %s %d", conf->host, conf->port); 
	status = system(cmd);
	if(WIFEXITED(status)){
    	if(WEXITSTATUS(status) != 0){
            goto SCAN_FAIL;
        }
	}else{
		goto SCAN_FAIL;
	}
	syslog(LOG_DEBUG, "ngrok proxy destination host network reachable");

	return NG_OK;

SCAN_FAIL:
	syslog(LOG_WARNING, "ngrok proxy destination host network unreachable");
	snprintf(cmd, sizeof(cmd), "echo %s > %s/ngroklink%d", 
									"error:destination host network unreachable",
									NGROK_LINK_DIR, pid);
	system(cmd);

	return NG_ERR;
}

int main(int argc, char *argv[])
{
	struct hostent *server = NULL;
	char *server_ip = NULL;
	char pidfilename[128] = {0};
	char config_file[64]={0};
	char con_type[64] = {0};
	int c;
	
	memset(&gl_ng_conf, 0, sizeof(NGROK_CONF));

	while ((c = getopt(argc, argv, "hf:s:p:t:i:l:a:c:r:u:d:k:")) != -1) {
		switch (c) {
		case 'h':
			usage();
		case 's':
			memcpy(gl_ng_conf.server_host, optarg, sizeof(gl_ng_conf.server_host));
			break;
		case 'p':
			gl_ng_conf.server_port = atoi(optarg);
			break;
		case 't':
			memcpy(gl_ng_conf.proto, optarg, sizeof(gl_ng_conf.proto));
			break;
		case 'i':
			memcpy(gl_ng_conf.host, optarg, sizeof(gl_ng_conf.host));
			break;
		case 'l':
			gl_ng_conf.port = atoi(optarg);
			break;
		case 'a':
            memcpy(gl_ng_conf.httpAuth, optarg, sizeof(gl_ng_conf.httpAuth));
			break;
		case 'r':
            memcpy(gl_ng_conf.tunnelId, optarg, sizeof(gl_ng_conf.tunnelId));
			break;
		case 'u':
            memcpy(gl_ng_conf.username, optarg, sizeof(gl_ng_conf.username));
			break;
		case 'd':
            memcpy(gl_ng_conf.password, optarg, sizeof(gl_ng_conf.password));
			break;
		case 'k':
			gl_ng_conf.keepalive = atoi(optarg) ? atoi(optarg) : DEFAULT_NGPROK_KEEPALIVE;
			break;
		case 'c':
			memcpy(con_type, optarg, sizeof(con_type));
			if (strncmp(con_type, "short", 1) == 0) {
				connect_type = CON_TYPE_SHORT;
			}else {
				connect_type = CON_TYPE_LONG;
			}
			break;
		case 'f':
			memcpy(config_file, optarg, sizeof(config_file));
			break;
		default:
			printf("ignore unknown arg: -%c %s", c, optarg ? optarg : "");
			break;
		}
	}
		
	if(config_file[0] 
		&& ngrok_config_parse(config_file)){
		return -1;
	}

	openlog(IDENT, LOG_PID, LOG_DAEMON);
	setlogmask(LOG_UPTO(LOG_INFO));
	
	pid = getpid();
	snprintf(pidfilename, sizeof(pidfilename), "/var/run/"IDENT"%d.pid", pid);
	write_pidtofile(pidfilename, pid);
	/* init signal handler */
	signal( SIGINT, signal_end );
	signal( SIGTERM, signal_end );
	signal( SIGUSR1, signal_user_open_debug);
	signal( SIGUSR2, signal_user_close_debug );

#if 0
	// scanning proxy host
	if(ngrok_scan_proxy_host(&gl_ng_conf) != NG_OK) {
		exit(-1);
	}*/
#endif

	if(ngrok_client_init(&gl_ng_client) != NG_OK){
		exit(-1);
	}

	ngrok_link_init();	
	syslog(LOG_INFO, "remotehost %s prot %d protocol %s localhost %s localport %d reqid %s keepalive %d", 
																	gl_ng_conf.server_host, gl_ng_conf.server_port, gl_ng_conf.proto, 
																	gl_ng_conf.host, gl_ng_conf.port, gl_ng_conf.tunnelId, gl_ng_conf.keepalive);
	ngrok_client_restart_timer(gl_ng_client.evtmr, 0.1);

	event_base_dispatch(gl_ng_client.base);

	closelog();

	close_ctrl_tunnel(&gl_ng_client);
	SSL_CTX_free(gl_ng_client.ssl_ctx);

	event_base_free(gl_ng_client.base);
	printf("exit");
	return 0;
}
