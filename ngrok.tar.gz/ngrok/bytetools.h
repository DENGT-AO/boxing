#ifndef _BYTESTOOLS_H_
#define _BYTESTOOLS_H_

#define BigEndian 1
#define LittleEndian 0


inline int BigEndianTest()
{
    unsigned int usData = 0x12345678;
    unsigned char *pucData = (unsigned char*)&usData;
    return *pucData == 0x78?LittleEndian:BigEndian;
}

#define Swap16(s) ((((s) & 0xff) << 8) | (((s) >> 8) & 0xff))
#define Swap32(l) (((l) >> 24) |(((l) &0x00ff0000) >> 8)|(((l) &0x0000ff00) << 8) |((l) << 24))
#define Swap64(ll) (((ll) >> 56) |(((ll) & 0x00ff000000000000LL) >> 40) |(((ll) & 0x0000ff0000000000LL) >> 24) |(((ll) & 0x000000ff00000000LL) >> 8)|(((ll) & 0x00000000ff000000LL) << 8) |(((ll) & 0x0000000000ff0000LL) << 24) |(((ll) & 0x000000000000ff00LL) << 40) |(((ll) << 56)))


#define BigEndian_16(s) BigEndianTest() ? s : Swap16(s)
#define LittleEndian_16(s) BigEndianTest() ? Swap16(s) : s
#define BigEndian_32(l) BigEndianTest() ? l : Swap32(l)
#define LittleEndian_32(l) BigEndianTest() ? Swap32(l) : l
#define BigEndian_64(ll) BigEndianTest() ? ll : Swap64(ll)
#define LittleEndian_64(ll) BigEndianTest() ? Swap64(ll) : ll


#endif

