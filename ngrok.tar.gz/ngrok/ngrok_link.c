/*
 * $Id: $ --
 *
 *  Ngrok link C File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 28/03/2017
 * Author: Henri HAN
 *
 */
#include <unistd.h>
#include <stddef.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <errno.h>
#include <event2/dns.h>
#include <event2/bufferevent_ssl.h>
#include <event2/util.h>
#include "ngrok_def.h"
#include "ngrok.h"

extern NG_LINK proxy_tunnel[MAX_LINK];
extern char localhost[32];
extern int localport;
extern char protocol[16];
extern CON_TYPE connect_type;

static void nglocal_eventcb(struct bufferevent *bev, short events, void *ptr);
static int create_local_link(NG_LINK *link, NGROK_CONF *conf);
static int ngremote_close_socket(NG_LINK *p);
static void ngremote_read_cb(struct bufferevent *bev, void *arg);
static void ngremote_event_cb(struct bufferevent *bev, short events, void *arg);
static void ngremote_write_cb(struct bufferevent *bev, void *arg);
static void ngrok_link_reinit(int i);

static void nglocal_write_cb(struct bufferevent *bev, void *arg);
static void nglocal_read_cb(struct bufferevent *bev, void *arg);
static void nglocal_tcp_eventcb(struct bufferevent *bev, short events, void *ptr);

static int ngrok_proxy_handle_callback(void *context, void *data, void *args);
static int ngrok_proxy_http_handle(void *context, void *data, void *args);
static int ngrok_proxy_https_handle(void *context, void *data, void *args);
static int ngrok_proxy_tcp_handle(void *context, void *data, void *args);

static NGROK_PROXY_CONTEXT ngrok_proxy_handle[] = {
	{
		.proto = "http", 
		.read_cb = nglocal_read_cb,
		.write_cb = NULL,
		.event_cb = nglocal_eventcb,
		.handle = ngrok_proxy_http_handle,
	},
	{
		.proto = "https", 
		.read_cb = nglocal_read_cb,
		.write_cb = nglocal_write_cb,
		.event_cb = nglocal_eventcb,
		.handle = ngrok_proxy_https_handle,
	},
	{
		.proto = "tcp", 
		.read_cb = nglocal_read_cb,
		.write_cb = nglocal_write_cb,
		.event_cb = nglocal_tcp_eventcb,
		.handle = ngrok_proxy_tcp_handle,
	}
};

static void ngrok_link_reinit(int i)
{
	proxy_tunnel[i].base = NULL;
	proxy_tunnel[i].ssl = NULL;
	proxy_tunnel[i].remote_bev = NULL;
	proxy_tunnel[i].local_bev = NULL;
	memset(proxy_tunnel[i].url, 0, sizeof(proxy_tunnel[i].url));
	memset(proxy_tunnel[i].clientaddr, 0, sizeof(proxy_tunnel[i].clientaddr)); 
	proxy_tunnel[i].stat = NGLINK_INIT;
	proxy_tunnel[i].id = -1;
}

void ng_free_ctx(struct bufferevent **bev)
{
    SSL *ssl = NULL;

	if(!bev || !(*bev)){
		return;
	}

	ssl = bufferevent_openssl_get_ssl(*bev);
	if(ssl){
		SSL_set_shutdown(ssl, SSL_RECEIVED_SHUTDOWN);
		SSL_shutdown(ssl);
	}

    bufferevent_free(*bev);
	*bev = NULL;
}

static void nglocal_eventcb(struct bufferevent *bev, short events, void *ptr)
{
	struct evbuffer *output = bufferevent_get_output(bev);
	struct evbuffer *input = bufferevent_get_input(bev);
	size_t outlen = evbuffer_get_length(output);
	size_t inlen = evbuffer_get_length(input);
	NG_LINK *link = (NG_LINK *)ptr;

	if (!link) {
		return;
	}

	if (events & BEV_EVENT_CONNECTED) {
		syslog(LOG_DEBUG, "id %d local Connect okay. clientaddr %s output buf len %d\n", link->id,  link->clientaddr, outlen);
	} else if (events & (BEV_EVENT_ERROR|BEV_EVENT_EOF)) {
		if(inlen && link->remote_bev != NULL && link->stat == NGLINK_CONNECTED){
	 		syslog(LOG_DEBUG, "id %d local link Closing, client addr %s, len %d\n",link->id,  link->clientaddr, inlen);
			evbuffer_remove_buffer(input, bufferevent_get_output(link->remote_bev), inlen);
			link->stat = NGLINK_FINISHED;
		}

        ng_free_ctx(&link->local_bev);
	}

}

static void nglocal_write_cb(struct bufferevent *bev, void *arg)
{
	NG_LINK *link = (NG_LINK *)arg;
	struct evbuffer *output = bufferevent_get_output(bev);
	size_t len = evbuffer_get_length(output);

	syslog(LOG_DEBUG, "send to local host, len: %d", len);
	// evbuffer_remove_buffer(output, bufferevent_get_output(bev), len);
}

static void nglocal_read_cb(struct bufferevent *bev, void *arg)
{
	NG_LINK *link = (NG_LINK *)arg;
	struct evbuffer *input = bufferevent_get_input(bev);
	size_t len = evbuffer_get_length(input);

	if (!link->remote_bev) {
		return;
	}
	
	syslog(LOG_DEBUG, "send to remote service, len: %d", len);
	//evbuffer_remove_buffer(input, bufferevent_get_output(link->remote_bev), len);

	if(len && link->remote_bev != NULL && link->stat == NGLINK_CONNECTED) {
 		syslog(LOG_DEBUG, "id %d local link Read, client addr %s, len %d\n",link->id,  link->clientaddr, len);	
		evbuffer_remove_buffer(input, bufferevent_get_output(link->remote_bev), len);
		//link->stat = NGLINK_FINISHED;
	}

}

static void nglocal_tcp_eventcb(struct bufferevent *bev, short events, void *ptr)
{
	struct evbuffer *output = bufferevent_get_output(bev);
	struct evbuffer *input = bufferevent_get_input(bev);
	size_t outlen = evbuffer_get_length(output);
	size_t inlen = evbuffer_get_length(input);
	NG_LINK *link = (NG_LINK *)ptr;

	if (events & BEV_EVENT_CONNECTED) {
		syslog(LOG_DEBUG, "id %d local Connect okay. clientaddr %s output buf len %d\n", link->id,  link->clientaddr, outlen);
	} else if (events & (BEV_EVENT_EOF|BEV_EVENT_ERROR|BEV_EVENT_TIMEOUT|BEV_EVENT_READING|BEV_EVENT_WRITING)) {
		if(inlen && link->remote_bev != NULL && link->stat == NGLINK_CONNECTED){
			syslog(LOG_DEBUG, "id %d local link Closing, client addr %s, len %d\n",link->id,  link->clientaddr, inlen);
			link->stat = NGLINK_FINISHED;
		}

	 	ng_free_ctx(&link->local_bev);
	}

}

static int ngrok_proxy_handle_callback(void *context, void *data, void *args)
{
	SSL_CTX *ctx = NULL;
	NG_LINK *link = NULL;
	NGROK_CONF *ngrok_conf = NULL;
	NGROK_PROXY_CONTEXT *ngrok_proxy_ctx = NULL;
	struct sockaddr_in sin;
	int keepAlive = 1;
	int KeepAliveProbes = 1;
	int KeepAliveIntvl = 2;
	int KeepAliveTime = 60;

	if(!context || !data || !args){
		return NG_PARAM_NULL;
	}

	link = (NG_LINK *)context;
	link->ssl = NULL;
	ngrok_conf = (NGROK_CONF *)data;
	ngrok_proxy_ctx = (NGROK_PROXY_CONTEXT *)args;

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr(ngrok_conf->host);
	sin.sin_port = htons(ngrok_conf->port);

	if(strcmp(ngrok_conf->proto, "https") == 0){
		ctx = evssl_init();
		if(NULL == ctx){
			syslog(LOG_ERR, "ssl context init err!");
			return NG_ERR;
		}

		link->ssl = SSL_new(ctx);
		if(NULL == link->ssl){
			syslog(LOG_ERR, "ngrok ssl init err!");
			goto PROXY_FAIL;
		}

		if (NULL == link->local_bev) {
			link->local_bev = bufferevent_openssl_socket_new(link->base, -1, link->ssl, BUFFEREVENT_SSL_CONNECTING, BEV_OPT_CLOSE_ON_FREE|BEV_OPT_DEFER_CALLBACKS);
		}
		if(NULL == link->local_bev) {
			syslog(LOG_ERR,"nglink Error constructing local ssl bufferevent!");
			goto PROXY_FAIL;
		}

		bufferevent_openssl_set_allow_dirty_shutdown(link->local_bev, 1);
	}else{
		link->local_bev = bufferevent_socket_new(link->base, -1, BEV_OPT_CLOSE_ON_FREE|BEV_OPT_DEFER_CALLBACKS);
		if(NULL == link->local_bev) {
			syslog(LOG_ERR,"nglink Error constructing local bufferevent!");
			goto PROXY_FAIL;
		}
	}

	if (connect_type == CON_TYPE_SHORT) {
		bufferevent_setcb(link->local_bev, NULL, 
						NULL, ngrok_proxy_ctx->event_cb, 
						(void *)link);
	} else {
		bufferevent_setcb(link->local_bev, ngrok_proxy_ctx->read_cb, 
						ngrok_proxy_ctx->write_cb, ngrok_proxy_ctx->event_cb, 
						(void *)link);
	}

	bufferevent_enable(link->local_bev, EV_READ|EV_WRITE);

	if(!strcmp(ngrok_conf->proto, "https")){
		setsockopt(bufferevent_getfd(link->local_bev), SOL_SOCKET, SO_KEEPALIVE, (void*)&keepAlive, sizeof(keepAlive));
		setsockopt(bufferevent_getfd(link->local_bev), IPPROTO_TCP, TCP_KEEPCNT, (void *)&KeepAliveProbes, sizeof(KeepAliveProbes));
		setsockopt(bufferevent_getfd(link->local_bev), IPPROTO_TCP, TCP_KEEPIDLE, (void *)&KeepAliveTime, sizeof(KeepAliveTime));
		setsockopt(bufferevent_getfd(link->local_bev), IPPROTO_TCP, TCP_KEEPINTVL, (void *)&KeepAliveIntvl, sizeof(KeepAliveIntvl));
	}

	if (bufferevent_socket_connect(link->local_bev, (struct sockaddr *)&sin, sizeof(struct sockaddr_in)) < 0) {
		syslog(LOG_ERR, "ngrok connect to local host %s:%d proto:%s failed", 
												ngrok_conf->host, ngrok_conf->port,
												ngrok_conf->proto);
		goto PROXY_FAIL;
	}

	return NG_OK;

PROXY_FAIL:
	if(link->local_bev){
		bufferevent_free(link->local_bev);
		link->local_bev = NULL;
	}

	if(link->ssl){
		SSL_free(link->ssl);
		link->ssl = NULL;
	}

	return NG_ERR;
}

static int ngrok_proxy_http_handle(void *context, void *data, void *args)
{
	return ngrok_proxy_handle_callback(context, data, args);
}

static int ngrok_proxy_https_handle(void *context, void *data, void *args)
{
	return ngrok_proxy_handle_callback(context, data, args); 
}

static int ngrok_proxy_tcp_handle(void *context, void *data, void *args)
{
	return ngrok_proxy_handle_callback(context, data, args);
}

static int create_local_link(NG_LINK *link, NGROK_CONF *conf)
{
	int ret = 0;
	NGROK_PROXY_CONTEXT *ngrok_proxy_ctx = NULL;

	if(!link || !conf){
		return NG_PARAM_NULL;
	}

	ngrok_proxy_ctx = NGROK_PROXY_HANDLE_CALLBACK(conf->proto);
	if(NULL == ngrok_proxy_ctx){
		syslog(LOG_ERR, "Unsupported protocol(%s)", conf->proto);
		return NG_ERR;
	}

	ret = ngrok_proxy_ctx->handle(link, conf, ngrok_proxy_ctx);
	if(ret == NG_OK){
		syslog(LOG_DEBUG,"create link id %d proto local sock connect ok", link->id);
	}

	return ret;
}

static void ngremote_write_cb(struct bufferevent *bev, void *arg)
{	
	NG_LINK *link = (NG_LINK *)arg;
	struct evbuffer *output = bufferevent_get_output(bev);
	size_t len = evbuffer_get_length(output);

	syslog(LOG_DEBUG, "ngremote link id %d write data stat %d len %d", link->id, link->stat, len);

	if(link->stat == NGLINK_FINISHED && len == 0){
		ngremote_close_socket(link);
	}
}

static int ngremote_close_socket(NG_LINK *link)
{

	ng_free_ctx(&link->remote_bev);

	syslog(LOG_DEBUG, "close ngremote socket, stat %d tunnel id %d", link->stat, link->id);
	ngrok_link_reinit(link->id);

	return NG_OK;
}

static void ngremote_read_cb(struct bufferevent *bev, void *arg)
{
	NG_LINK *link = (NG_LINK *)arg;
	struct evbuffer *input = bufferevent_get_input(bev);
	size_t len = evbuffer_get_length(input);	
	unsigned long long packlen;
	NGROK_CLIENT *ngrok_client = &gl_ng_client;
	NGROK_CONF *ngrok_conf = &gl_ng_conf;

	syslog(LOG_DEBUG, "nglink id %d readcb stat %d len %d", link->id, link->stat, len);

	if(link->stat == NGLINK_REMOTED) {
		ngrok_client_restart_timer(ngrok_client->hbtmr, ngrok_client->keepalive);

		if(len > NGROK_PACK_HDR_SIZE) { // 8 bytes package header
			evbuffer_copyout(input, (void *)&packlen, NGROK_PACK_HDR_SIZE); // read payload length
			syslog(LOG_DEBUG, "nglink id %d get package len %lld", link->id, packlen);

			if(len >= packlen + NGROK_PACK_HDR_SIZE){
				evbuffer_drain(input, NGROK_PACK_HDR_SIZE); // skip 8 bytes package header 
				ngproxy_packet_parse(link, input, (int)packlen);
			}
		}
	}else if(link->stat == NGLINK_CONNECTED) {
		ngrok_client_restart_timer(ngrok_client->hbtmr, ngrok_client->keepalive);
		if(len){
			if(NULL == link->local_bev){
				create_local_link(link, ngrok_conf);
			}
			evbuffer_remove_buffer(input, bufferevent_get_output(link->local_bev), len);
		}
	} else {
		syslog(LOG_ERR, "nglink readcb stat error %d", link->stat);
	}
}

static void ngremote_event_cb(struct bufferevent *bev, short events, void *arg)
{
	NG_LINK *link = (NG_LINK *)arg;

	if(events & BEV_EVENT_CONNECTED){
		syslog(LOG_DEBUG, "ngremote Connection created. link id %d\n", link->id);
		link->stat = NGLINK_REMOTED;
	}else if (events & (BEV_EVENT_EOF|BEV_EVENT_ERROR|BEV_EVENT_TIMEOUT|BEV_EVENT_READING|BEV_EVENT_WRITING)) {
		if(!(events & BEV_EVENT_EOF)){
			syslog(LOG_ERR, "ngremote got an error on the connection: %s \n", evutil_socket_error_to_string(EVUTIL_SOCKET_ERROR()));
		}
		ngremote_close_socket(link);
	}
}

int create_ngrok_tunnel(NGROK_TUNNEL_TYPE type, NGROK_CLIENT *client, NG_LINK *link,
							NGROK_TUNNEL_RDWR_CALLBACK read_cb, NGROK_TUNNEL_RDWR_CALLBACK write_cb, 
							NGROK_TUNNEL_EVENT_CALLBACK event_cb, void *args)
{
	SSL_CTX *ctx = NULL;
	SSL *ssl = NULL;
	struct bufferevent *bev = NULL;
	struct event_base *base = NULL;
	struct sockaddr *sin = NULL;

	if(!client){
		return NG_PARAM_NULL;
	}

	base = client->base;
	sin = (struct sockaddr *)&client->sin;

	if(type == NGROK_PROXY_TUNNEL && link){
		link->base = client->base;
	}

	ctx = evssl_init();
	if(NULL == ctx){
		syslog(LOG_ERR, "ssl context init err!");
		return NG_ERR;
	}

	ssl = SSL_new(ctx);
	if(NULL == ssl){
		syslog(LOG_ERR, "ngrok ssl init err!");
		goto CREATE_TUNNEL_FAIL;
	}

	bev = bufferevent_openssl_socket_new(base, -1, ssl, BUFFEREVENT_SSL_CONNECTING, BEV_OPT_CLOSE_ON_FREE|BEV_OPT_DEFER_CALLBACKS);
	if(NULL == bev) {
		syslog(LOG_ERR,"nglink Error constructing bufferevent!");
		goto CREATE_TUNNEL_FAIL;
	}

	if(type == NGROK_CTRL_TUNNEL){
		client->ssl = ssl;
		client->bev = bev;
	}else if(type == NGROK_PROXY_TUNNEL){
		link->ssl = ssl;
		link->remote_bev = bev;
	}

	bufferevent_openssl_set_allow_dirty_shutdown(bev, 1); 
	bufferevent_setcb(bev , read_cb, write_cb, event_cb, (void *)args);
	bufferevent_enable(bev, EV_WRITE|EV_READ);
	if(type == NGROK_CTRL_TUNNEL){
		bufferevent_setwatermark(bev, EV_READ, 16, 0);
	}

	if(type == NGROK_PROXY_TUNNEL){
		// ngrok register proxy
		if(send_ng_msg("RegProxy", link) != NG_OK){
			goto CREATE_TUNNEL_FAIL;
		}
	}

	if(bufferevent_socket_connect(bev, (struct sockaddr *)sin, sizeof(struct sockaddr_in)) < 0) {
		syslog(LOG_ERR,"nglink connnect remote error");
        goto CREATE_TUNNEL_FAIL;
  	}

	if(type == NGROK_CTRL_TUNNEL){
		syslog(LOG_DEBUG, "ngrok create control tunnel success.");
	}else if(type == NGROK_PROXY_TUNNEL){
		syslog(LOG_DEBUG,"nglink create new proxy tunnel success(id:%d).", link->id);
	}

	return NG_OK;

CREATE_TUNNEL_FAIL:
	if(bev){
		bufferevent_free(bev);
		bev = NULL;
	} else {
		if(ssl){
			SSL_free(ssl);
			ssl = NULL;
		}
	}

	return NG_ERR;
}

int create_remote_link(NGROK_CLIENT *client, NG_LINK *link)
{
	return create_ngrok_tunnel(NGROK_PROXY_TUNNEL, client, link, ngremote_read_cb, ngremote_write_cb, ngremote_event_cb, link);
}

int ngrok_link_init()
{
	int i = 0;

	if(access(NGROK_LINK_DIR, F_OK)){
		mkdir(NGROK_LINK_DIR, 0755);
	}

	for(i = 0; i< MAX_LINK; i++){
		proxy_tunnel[i].base = NULL;
		proxy_tunnel[i].ssl = NULL;
		proxy_tunnel[i].remote_bev = NULL;
		proxy_tunnel[i].local_bev = NULL;
		memset(proxy_tunnel[i].url, 0, sizeof(proxy_tunnel[i].url));
		memset(proxy_tunnel[i].clientaddr, 0, sizeof(proxy_tunnel[i].clientaddr)); 
		proxy_tunnel[i].stat = NGLINK_INIT;
		proxy_tunnel[i].id =  -1;
	}

	return NG_OK;
}

