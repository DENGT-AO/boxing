/*
 * $Id: $ --
 *
 *  Ngrok Client Head File
 *
 * Copyright (c) 2001-2017 InHand Networks, Inc.
 *
 * PROPRIETARY RIGHTS of InHand Networks are involved in the
 * subject matter of this material.  All manufacturing, reproduction,
 * use, and sales rights pertaining to this subject matter are governed
 * by the license agreement.  The recipient of this software implicitly
 * accepts the terms of the license.
 *
 * Creation Date: 30/03/2017
 * Author: Henri HAN
 *
 */
#ifndef _NGROK_H_
#define _NGROK_H_

#include "ngrok_def.h"

extern NGROK_CLIENT gl_ng_client;
extern NGROK_CONF gl_ng_conf;
extern pid_t pid;

extern int create_remote_link(NGROK_CLIENT *client, NG_LINK *link);
extern int ngrok_link_init();

extern int create_ngrok_tunnel(NGROK_TUNNEL_TYPE type, NGROK_CLIENT *client, NG_LINK *link,
							NGROK_TUNNEL_RDWR_CALLBACK read_cb, NGROK_TUNNEL_RDWR_CALLBACK write_cb, 
							NGROK_TUNNEL_EVENT_CALLBACK event_cb, void *args);
extern int create_ctrl_tunnel(NGROK_CLIENT *client);
extern int close_ctrl_tunnel(NGROK_CLIENT *client);

extern int ngctrl_packet_parse(NGROK_CLIENT *client, struct evbuffer *input, int len);
extern int ngproxy_packet_parse(NG_LINK *remote, struct evbuffer *input, int len); 

extern int send_ng_reg_proxy(NG_LINK *link, NGROK_PRIO *prio);
extern int send_ng_msg(const char *type, void *context);

extern int ngrok_client_init(NGROK_CLIENT *p);
extern void ngrok_client_restart_timer(struct event *evtmr, int interval);

extern void ng_free_ctx(struct bufferevent **bev);
SSL_CTX * evssl_init(void);

#endif
 
