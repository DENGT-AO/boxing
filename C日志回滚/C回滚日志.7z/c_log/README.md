### modify the code according to git@github.com:rxi/log.c.git, thank rxi very much!
