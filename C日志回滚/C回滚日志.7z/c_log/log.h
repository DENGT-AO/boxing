#ifndef __LOG_H__
#define __LOG_H__

#include <stdio.h>
#include <stdarg.h>

#define LOG_VERSION "0.1.0"

typedef void (*log_LockFn)(void *data, int lock);

struct log_conf {
    void *data;
    log_LockFn lock;
    char file_name[64];             // log file name
    FILE *fp;                       // log file pointer
    int max_size;                   // log file max size, if go beyond the limit, it will come back to file start.  
    int level;                      // only if log function's level not more than the value, it will output log data. 
    int quiet;                      // 0: print data to the standard output and log file; 1: only print data to log file 
    int print_color;                // when 1, it will print level name with color to standard output.
} ;

enum {
    LOG_FATAL,
    LOG_ERROR, 
    LOG_WARN, 
    LOG_INFO, 
    LOG_DEBUG, 
    LOG_TRACE 
};

#define log_fatal(...) log_log(LOG_FATAL, __FILE__, __LINE__, __VA_ARGS__)
#define log_error(...) log_log(LOG_ERROR, __FILE__, __LINE__, __VA_ARGS__)
#define log_warn(...)  log_log(LOG_WARN,  __FILE__, __LINE__, __VA_ARGS__)
#define log_info(...)  log_log(LOG_INFO,  __FILE__, __LINE__, __VA_ARGS__)
#define log_debug(...) log_log(LOG_DEBUG, __FILE__, __LINE__, __VA_ARGS__)
#define log_trace(...) log_log(LOG_TRACE, __FILE__, __LINE__, __VA_ARGS__)

int log_init(struct log_conf *conf);
void log_log(int level, const char *file, int line, const char *fmt, ...);

#endif
