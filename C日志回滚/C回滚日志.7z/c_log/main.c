/*********************************************************************
 * State:
 *       1. If you remove -D MULTI_THREAD and -lpthread from Makefile,
 *          it changes to be a normal process with only one thread.
 *       2. When you use the log util in your project, only need two
 *          step:
 *              1) put log.c and log.h in your project.
 *              2) in c file include log.h and init a struct lconf
 *                 instance, then call log_init().
 *********************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <string.h>

#ifdef MULTI_THREAD
#include <pthread.h>
#define THREAD_NUM      3
#endif

#include "log.h"

#define LOG_FILE        "/tmp/nowlan_log"

#ifdef MULTI_THREAD
inline void *print_log(void *arg) 
{
    /*
     * If the fourth arg of pthread_create() is (void *)i,
     * here should be thread_id = (long)i to change an address 
     * to a long int number.
     */
    unsigned long long thread_id = *((unsigned long long *)arg);
    int log_level = thread_id % THREAD_NUM;

    while (1) {
        // Try to match from 0 to 2(THREAD_NUM - 1).
        switch (log_level) {
            case 0:
                log_error("Thread-%d: Hello zero", thread_id);
                break;
            case 1:
                log_info("Thread-%d: Hello one", thread_id);
                break;
            case 2:
            default:
                log_trace("Thread-%d: Hello two", thread_id);
                break;
        }
        sleep(3);
    }
}

void log_lock(void *data, int status)
{
    if (NULL == data) 
        return;

    if (status) {
        pthread_mutex_lock((pthread_mutex_t *)data);
        // printf("%-*s ------------->\n", 6, "Lock");
    } else {
        pthread_mutex_unlock((pthread_mutex_t *)data);
        //printf("%-*s <-------------\n\n", 6, "Unlock");
    }
}
#endif

int main(void)
{
    int retval;
    unsigned long long i = 0;
    struct log_conf lconf;
#ifdef MULTI_THREAD
    unsigned long long p_arg[THREAD_NUM];
    pthread_t p_id[THREAD_NUM];
    pthread_mutex_t log_mutex;
    pthread_mutex_init(&log_mutex, NULL);  
#endif

    FILE *fp = fopen(LOG_FILE, "a+");
    if (NULL == fp) {
        printf("fopen() failed.\n");
        return -1;
    }

    memset(&lconf, 0, sizeof(struct log_conf));
#ifdef MULTI_THREAD
    lconf.data         = &log_mutex;
    lconf.lock         = log_lock;
#endif
    lconf.fp           = fp;
    //lconf.quiet      = 1;     // quiet = 1, only print data to file but not to standard output.              
    lconf.print_color  = 1;     // It affacts data that is print to standard output.
    lconf.level        = LOG_TRACE;
    lconf.max_size     = 100 * 1024;   // 100k
    strncpy(lconf.file_name, LOG_FILE, sizeof(lconf.file_name) - 1);
    retval = log_init(&lconf);
    if (retval < 0) {
#ifdef MULTI_THREAD
        pthread_mutex_destroy(&log_mutex);  
#endif
        printf("log init failed.\n");
        return -1;
    }

#ifdef MULTI_THREAD
    for (i = 0; i < THREAD_NUM; i++) {
        p_arg[i] = i;
        /*
         * the fourth arg must not be (void*)&i.
         * except (void *)&p_arg[i]), (void *)i is another choice.
         */
        retval = pthread_create(&p_id[i], NULL, print_log, (void *)&p_arg[i]);
        if (retval) {
            printf("Failed to create thread-%llu\n", i);
        }
    }

    /*
     * pthread_join() advoid main thread exit.
     * A while(1) Loop with sleep works well too.
     */
    for (i = 0; i < THREAD_NUM; i++) {
        pthread_join(p_id[i], NULL);
    }
    pthread_mutex_destroy(&log_mutex);  
#else 
    while (1) {
        if (i % 2 == 0)
            log_trace("%d-hello %s", i++, "world");    
        else 
            log_error("%d-hello %s", i++, "world");    

        sleep(3);
    }
#endif

    fclose(fp);

    return 0;
}
