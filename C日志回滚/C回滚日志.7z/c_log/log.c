#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/types.h>

#include "log.h"

struct log_conf g_log;

/*
 * 功能：通过转义序列设置终端颜色属性,和语言无关
 * 格式：\033[显示方式;前景色;背景色m输出字符串\033[0m
 * 显示方式：
 *          0(默认)、1(粗体/高亮)、22(非粗体)、4(单条下划线)、
 *          24(无下划线)、5(闪烁)、25(无闪烁)、
 *          7(反显、翻转前景色和背景色)、27(无反显)
 * 颜    色：
 *          0(黑)、1(红)、2(绿)、3(黄)、4(蓝)、5(洋红)、6(青)、7(白)
 *          前景色为30+颜色值，如31表示前景色为红色；
 *          背景色为40+颜色值，如41表示背景色为红色
 */
static const char *level_colors[] = {
    "\033[0;31m",
    "\033[0;31m",
    "\033[0;33m",
    "\033[0;33m",
    "\033[0;34m",
    "\033[0;34m"
};

static const char *level_names[] = {
    "FATAL",
    "ERROR",
    "WARN", 
    "INFO",
    "DEBUG", 
    "TRACE"
};

int log_init(struct log_conf *conf)
{
    if (NULL == conf) {
        return -1;
    }
    memcpy(&g_log, conf, sizeof(struct log_conf));

    return 0;
}

static void lock(void)   
{
    if (g_log.lock) 
        g_log.lock(g_log.data, 1);
}

static void unlock(void) 
{
    if (g_log.lock) 
        g_log.lock(g_log.data, 0);
}

void log_log(int level, const char *file, int line, const char *fmt, ...) 
{
    if (level > g_log.level) {
        return;
    }

    /* Acquire lock */
    lock();

    /* Get current time */
    time_t t = time(NULL);
    struct tm *lt = localtime(&t);

    /* Log to stderr */
    if (!g_log.quiet) {
        va_list args;
        char buf[32];

        buf[strftime(buf, sizeof(buf), "[%Y-%m-%d %H:%M:%S]", lt)] = '\0';

        if (g_log.print_color) {
            // string after \033[0m will recover default color.
            fprintf(stderr, "%s %s%-5s\033[0m %s:%d  ",
                    buf,
                    level_colors[level], 
                    level_names[level],
                    file,
                    line);
        } else {
            fprintf(stderr, "%s %-5s %s:%d  ",
                    buf,
                    level_names[level],
                    file,
                    line);
        } 

        va_start(args, fmt);
        vfprintf(stderr, fmt, args);
        va_end(args);
        fprintf(stderr, "\n");
    }

    /* Log to file */
    if (g_log.fp) {
        va_list args;
        char buf[32];
        struct stat st_info;  

        // log file rollback to avoid eating up space for a long time.
        stat(g_log.file_name, &st_info);  
        if (st_info.st_size > g_log.max_size) {
            truncate(g_log.file_name, 0);
            fseek(g_log.fp, 0, SEEK_SET);
        }

        buf[strftime(buf, sizeof(buf), "[%Y-%m-%d %H:%M:%S]", lt)] = '\0';
        fprintf(g_log.fp, "%s %-5s %s:%d  ", 
                buf, 
                level_names[level], 
                file, 
                line);

        va_start(args, fmt);
        vfprintf(g_log.fp, fmt, args);
        va_end(args);
        fprintf(g_log.fp, "\n");

        /* flush buffer data to log file immediately */
        fflush(g_log.fp);
    }

    /* Release lock */
    unlock();
}
